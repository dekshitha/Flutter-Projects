class GroceryData{
  static List<Map<String, dynamic>> groceryList = [
    {"id":1,"name": "Apples", "category": "Produce", "price": 1.99, "quantity": 5, "image": "http://example.com/images/apples.jpg"},
    {"id":2,"name": "Bread", "category": "Bakery", "price": 2.49, "quantity": 1, "image": "http://example.com/images/bread.jpg"},
    {"id":3,"name": "Eggs", "category": "Dairy", "price": 3.99, "quantity": 12, "image": "http://example.com/images/eggs.jpg"},
    {"id":4,"name": "Milk", "category": "Dairy", "price": 2.69, "quantity": 1, "image": "http://example.com/images/milk.jpg"},
    {"id":5,"name": "Chicken Breast", "category": "Meat", "price": 6.99, "quantity": 2, "image": "http://example.com/images/chicken_breast.jpg"},
    {"id":6,"name": "Broccoli", "category": "Produce", "price": 1.49, "quantity": 1, "image": "http://example.com/images/broccoli.jpg"},
    {"id":7,"name": "Spaghetti", "category": "Pasta", "price": 0.99, "quantity": 1, "image": "http://example.com/images/spaghetti.jpg"},
    {"id":8,"name": "Tomato Sauce", "category": "Canned Goods", "price": 1.29, "quantity": 1, "image": "http://example.com/images/tomato_sauce.jpg"},
    {"id":9,"name": "Rice", "category": "Grains", "price": 4.99, "quantity": 1, "image": "http://example.com/images/rice.jpg"},
    {"id":10,"name": "Bananas", "category": "Produce", "price": 0.99, "quantity": 6, "image": "http://example.com/images/bananas.jpg"},
  ];

}